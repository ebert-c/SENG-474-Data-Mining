Attributions to scikit-learn and matplotlib


To run the code, simply run any of the 3 files, (svm, neural_network, or comparison) svm contains both gaussian and linear svm code.
The code will run and produce graphs similar to those shown in the report.